<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; 
use Illuminate\Support\Facades\Session;// Import the DB facade

class SellController extends Controller
{
    public function show($id)
    {
        $admin = Session::get('admin');
    
        if (!$admin) {
            return redirect('/');
        }
    
        // Retrieve the data from the 'sales' and 'selling' tables
        $medicine = DB::table('sales')->where('sales_id', $id)->get();
        $sale = DB::table('selling')->where('id', $id)->first();
    
        return view('sellView', compact('medicine', 'sale'));
    }
    
    public function bulkSell()
    {
        $admin = Session::get('admin');

        if (!$admin) {
            return redirect('/');
        }

        return view('bulkSell');
    }
    public function sales(Request $request)
    {
        $admin = Session::get('admin');

        if (!$admin) {
            return redirect('/');
        }
        $search = $request->input('search') ?? '';
    
        // Build a query using raw SQL to join the "sales" and "medicines" tables
        $query = DB::table('selling')
            ->select('*')
            ->orderBy("id","desc");
    
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('date', 'like', '%' . $search . '%')
                  ->orWhere('customer_name', 'like', '%' . $search . '%');
            });
        }
    
        // Get the results and paginate
        $sales = $query->paginate(10);
    
        return view('sales', compact('sales', 'search'));
    }
    

}

<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    public function logout()
    {
        Session::forget('admin');
        return redirect('/');
    }

    public function showLoginForm()

    {
       
        return view('login');
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');
        $admin = DB::table('admins')->where('username', $credentials['email'])->first();

        if ($admin && password_verify($credentials['password'], $admin->password)) {
            Session::put('admin', $admin);
            return redirect()->intended('/dashboard');
        }

        // Authentication failed
        return back()->withErrors(['email' => 'Invalid credentials']);
    }
    public function showDashboard()
    {
        // $admin = Session::get('admin');

        
        $currentMonth = Carbon::now()->month;

        $query = DB::table('selling')
            ->select(
                '*',
                DB::raw('total_selling_price - total_cost_price as profit')
            )
            ->whereMonth('date', $currentMonth)
            
            ->get();
    
        $sumProfit = $query->sum('profit');
        $sumSales = $query->sum('total_selling_price');
        $query = DB::table('medicines')
            ->select(
                '*'
            )
            ->whereMonth('date', $currentMonth)
            ->get();
        $sumPurchase = $query->sum('cost_price');
        
    
        // User is authenticated; load the dashboard and pass the data to the view
        return view('dashboard', [
            // 'admin' => $admin,
            'sumProfit' => $sumProfit,
            'sumSales' => $sumSales,
            'sumPurchase' => $sumPurchase
        ]);
    }

}

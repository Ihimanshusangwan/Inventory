<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\YourModel;
use Illuminate\Support\Facades\DB; 

class ApiController extends Controller
{
    public function getData(Request $request)
    {
        $startDate = $request->input('start');
        $endDate = $request->input('end');
        $type = $request->input('type');
        if ($type == "sales") {
            $data = DB::table('selling')
            ->select('*')
            ->whereBetween('date', [$startDate,$endDate])
            ->orderBy("id", "desc")
            ->get();
        
            $totalProfit = $data->sum(function ($item) {
                return $item->total_selling_price - $item->total_cost_price;
            });
            $totalSale = $data->sum(function ($item) {
                return $item->total_selling_price;
            });

            return response()->json(['table' => $data, 'totalProfit' => $totalProfit, 'totalSale' => $totalSale]);

        } else {
            $data = DB::table('medicines')
                ->select('*')
                ->whereBetween('date', [$startDate, $endDate]) 
                ->orderBy("id", "desc")
                ->get();
            $totalCost = $data->sum(function ($item) {
                return $item->cost_price;
            });
            return response()->json(['table' => $data, 'totalCost' => $totalCost]);

        }


    }
    public function getMedicine(Request $request)
    {
        $inputValue = $request->input('input');
    
        $data = DB::table('medicines')
            ->select('*')
            ->where('medicine_name', 'like', '%' . $inputValue . '%')
            ->distinct()
            ->get();
    
        // Return the results as a JSON response
        return response()->json($data);
       
    }




}

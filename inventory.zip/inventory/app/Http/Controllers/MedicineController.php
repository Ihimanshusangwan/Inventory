<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Medicine;
use Illuminate\Support\Facades\DB; 
use Illuminate\Support\Facades\Session;

class MedicineController extends Controller
{
    public function create()
    {
        $admin = Session::get('admin');

        if (!$admin) {
            return redirect('/');
        }
    
        return view('medicine');
    }
    public function store(Request $request)
    {
        $admin = Session::get('admin');

        if (!$admin) {
            return redirect('/');
        }
        $data = $request->validate([
            'date' => 'required|date',
            'medicine_name' => 'required|string',
            'batch_number' => 'required|string',
            'mrp' => 'required|numeric',
            'cost_price' => 'required|numeric',
        ]);
        // Manually insert data into the 'medicines' table
        DB::table('medicines')->insert([
            'date' => $data['date'],
            'medicine_name' => $data['medicine_name'],
            'batch_number' => $data['batch_number'],
            'mrp' => $data['mrp'],
            'cost_price' => $data['cost_price'],
        ]);

        return redirect('/add-medicine')->with('success', 'Medicine added successfully!');

    }

    public function sell(Request $request)
    {
        $customerName = $request->input('customer_name');
        $date = $request->input('sale_date');
        $total = $request->input('total_amount');
        $total_cp = $request->input('total_cost_price');
        $i=1;
        $insertedId = DB::table('selling')->insertGetId([
            'customer_name' => $customerName,
            'date' => $date,
            'total_selling_price' => $total,
            'total_cost_price' => $total_cp,
        ]);

        while ($request->has("med_name_$i")) {
            $medName = $request->input("med_name_$i");
    
            if (!empty($medName)) {
                $sp = $request->input("sp_$i");
                $cost_price = $request->input("cost_$i");
                $batch_no = $request->input("batch_number_$i");
               
                // Insert prescription data using Laravel query builder
                DB::table('sales')->insert([
                    'sales_id' => $insertedId,
                    'medicine_name' => $medName,
                    'batch_number' => $batch_no,
                    'selling_price' => $sp,
                    'cost_price' => $cost_price
                    
                ]);
    
                $i++;
            } else {
                $i++;
            }
    
           
        }
    
        return redirect()->back()->with('success', 'Medicines sold successfully.');
    

    }
    public function show(Request $request)
    {
        // $admin = Session::get('admin');

        // if (!$admin) {
        //     return redirect('/');
        // }
        $search = $request->input('search') ?? '';

        // Build a query to search across multiple columns using the DB facade
        $query = DB::table('medicines');

        if ($search) {
            $query->where('date', 'like', '%' . $search . '%')
                ->orWhere('medicine_name', 'like', '%' . $search . '%')
                ->orWhere('batch_number', 'like', '%' . $search . '%')
                ->orWhere('mrp', 'like', '%' . $search . '%')
                ->orWhere('cost_price', 'like', '%' . $search . '%');
            
        }
        $query->orderBy("id", "desc");

        // Get the results and paginate
        $medicines = $query->paginate(10);


        return view('showMedicine', compact('medicines', 'search'));
    }
}


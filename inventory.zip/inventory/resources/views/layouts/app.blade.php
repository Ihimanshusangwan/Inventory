<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Your Application')</title>
    
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <style>
        .dropdown-container {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 4px;
    z-index: 1;
  }

  .dropdown-row {
    padding: 4px;
    cursor: pointer;
  }

  .dropdown-row:hover {
    background-color: #ddd;
  }
    </style>
</head>
<body>
<nav class="bg-blue-600 p-4 text-white">
    <div class="container mx-auto">
        <div class="flex justify-between items-center">
        <h1 class="text-2xl font-semibold" >Webifly Solutions</h1>

            <ul class="flex space-x-4">
                <li><a href="{{route('dashboard')}}" class="hover:text-gray-200">Dashboard</a></li>
                <li><a href="{{route('medicine.add')}}" class="hover:text-gray-200">Add Medicine</a></li>
                <li><a href="{{route('medicine.bulk')}}" class="hover:text-gray-200">Sell Medicines</a></li>
                <li><a href="{{route('sales')}}" class="hover:text-gray-200">Sales History</a></li>
                <li>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="text-white hover:text-gray-200 focus:outline-none">
                            Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
    @yield('content')
    <script src="{{ asset('js/app.js') }}"></script>
</body>
</html>

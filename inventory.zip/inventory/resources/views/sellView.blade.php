@extends('layouts.app')

@section('title', 'Sell Medicine')

@section('content')
    <div class="p-6">
        <h2 class="text-2xl font-semibold mb-4">Sales Receipt</h2>

        <div class="bg-white p-6 shadow-md sm:rounded-lg">
            <h3 class="text-lg font-medium mb-2">Customer: {{ $sale->customer_name }}</h3>
            <p>Date: {{ $sale->date }}</p>
            <p>Total: {{ $sale->total_selling_price }}</p>
            <p>Total Cost Price: {{ $sale->total_cost_price }}</p>
            <p>Profit: {{ $sale->total_selling_price - $sale->total_cost_price }}</p>
        </div>

        @if ($medicine->isNotEmpty())
            <h2 class="text-2xl font-semibold mt-4">Medicine Details</h2>
            <table class="table-auto">
                <thead>
                    <tr>
                        <th class="px-4 py-2">Medicine Name</th>
                        <th class="px-4 py-2">Batch Number</th>
                        <th class="px-4 py-2">Cost Price</th>
                        <th class="px-4 py-2">Selling Price</th>
                        <th class="px-4 py-2">Profit</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($medicine as $med)
                        <tr>
                            <td class="px-4 py-2">{{ $med->medicine_name }}</td>
                            <td class="px-4 py-2">{{ $med->batch_number }}</td>
                            <td class="px-4 py-2">{{ $med->cost_price }}</td>
                            <td class="px-4 py-2">{{ $med->selling_price }}</td>
                            <td class="px-4 py-2" style="color: {{ $med->selling_price - $med->cost_price >= 0 ? 'green' : 'red' }}">
                                {{ ($med->selling_price - $med->cost_price >= 0 ? '+' : '-') . abs($med->selling_price - $med->cost_price) }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <p>No medicine details found for this sale.</p>
        @endif
    </div>
@endsection

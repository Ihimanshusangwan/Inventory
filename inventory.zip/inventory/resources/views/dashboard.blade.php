@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class=" flex flex-row  justify-around pt-16">
    <div class="w-96 mb-4">
        <div class="bg-green-400 rounded-lg shadow-md text-white p-4">
            <p class="font-bold text-lg">PROFIT ({{ now()->format('F') }})</p>
            <p class="text-xl">Rs. {{$sumProfit}}</p>
        </div>
    </div>
    <div class="w-96 mb-4">
        <div class="bg-purple-500 rounded-lg shadow-md text-white p-4">
            <p class="font-bold text-lg">SALES ({{ now()->format('F') }})</p>
            <p class="text-xl">Rs. {{$sumSales}}</p>
        </div>
    </div>
    <div class="w-96">
        <div class="bg-yellow-400 rounded-lg shadow-md text-white p-4">
            <p class="font-bold text-lg">PURCHASE ({{ now()->format('F') }})</p>
            <p class="text-xl">Rs. {{$sumPurchase}}</p>
        </div>
    </div>
</div>

<h2 class="text-2xl font-semibold m-4">View History</h2>

<div date-rangepicker class="flex items-center m-8">
  <div class="relative">
    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
         <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
          <path d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z"/>
        </svg>
    </div>
    <input name="start" id="start-date" type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Select date start">
  </div>
  <span class="mx-4 text-gray-500">to</span>
  <div class="relative">
    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
         <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
          <path d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z"/>
        </svg>
    </div>
    <input name="end" id="end-date" type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Select date end">
</div>

<select id="type" style="width:12rem; " class=" mx-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
  <option value="sales" selected>Sales</option>
  <option value="purchase">Purchase</option>
</select>


<button id="search-button"  class="bg-blue-500 text-white mx-3 py-2 px-4 rounded hover:bg-blue-600">Search</button>
</div>
<div id="result">
    
</div>


<script src="{{ asset('js/datepicker.min.js') }}"></script>
<script src="{{ asset('js/filter.js') }}"></script>


@endsection

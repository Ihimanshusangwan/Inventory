

<?php $__env->startSection('title', 'Sell Medicine'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h2 class="text-2xl font-semibold mb-4">Sell Medicine</h2>
        <?php if(session('success')): ?>
                <p class="text-green-600 font-medium mb-2"><?php echo e(session('success')); ?></p>
            <?php endif; ?>

        <div class="bg-white p-6 shadow-md sm:rounded-lg">
            <h3 class="text-lg font-medium mb-2"><?php echo e($medicine->medicine_name); ?></h3>
            <p>Date: <?php echo e($medicine->date); ?></p>
            <p>Batch Number: <?php echo e($medicine->batch_number); ?></p>
            <p>MRP: <?php echo e($medicine->mrp); ?></p>
            <p>Cost Price: <?php echo e($medicine->cost_price); ?></p>

            <!-- Add your selling form here -->
            <form action="" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Customer Name Input -->
    <div class="mb-6">
        <label for="customer_name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Customer Name</label>
        <input type="text" name="customer_name" id="customer_name" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
    </div>

    <!-- Date Input -->
    <div class="mb-6">
        <label for="sale_date" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Selling Date</label>
        <input type="date" name="sale_date" id="sale_date" value="<?php echo e(now()->format('Y-m-d')); ?>" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
    </div>

    <!-- Selling Price Input -->
    <div class="mb-6">
        <label for="selling_price" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Selling Price</label>
        <input type="text" name="selling_price" id="selling_price" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
    </div>

    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
        Sell
    </button>
</form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u567464706/domains/webiflysolutions.com/public_html/inventory/resources/views/sell.blade.php ENDPATH**/ ?>
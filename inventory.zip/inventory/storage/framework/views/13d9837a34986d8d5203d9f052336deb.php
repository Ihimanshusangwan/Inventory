

<?php $__env->startSection('title', 'Add Medicine'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-gray-200 flex items-center justify-center h-screen">

<div class="bg-white rounded-lg shadow-md p-6 w-96">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6">Add New Medicine</h1>
        <?php if(session('success')): ?>
            <div class="bg-green-200 border-l-4 border-green-600 p-4 mt-4 text-green-800">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="" class="mb-6">
    <?php echo csrf_field(); ?>

    <div class="relative z-0 mb-6 group">
        <label for="date" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date:</label>
        <input type="date" id="date" name="date" value="<?php echo e(now()->format('Y-m-d')); ?>" class="form-input block w-full py-2.5 px-0 text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" required />
        
    </div>

    <div class="relative z-0 mb-6 group">
        <label for="medicine_name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Medicine Name:</label>
        <textarea id="medicine_name" name="medicine_name" class="form-input block w-full py-2.5 px-0 text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" required></textarea>
       
    </div>

    <div class="relative z-0 mb-6 group">
        <label for="batch_number" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Batch Number:</label>
        <input type="text" id="batch_number" name="batch_number" class="form-input block w-full py-2.5 px-0 text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" required />
       
    </div>

    <div class="relative z-0 mb-6 group">
        <label for="mrp" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">MRP (Maximum Retail Price):</label>
        <input type="number" id="mrp" name="mrp" class="form-input block w-full py-2.5 px-0 text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" step="0.01" required />
       
    </div>

    <div class="relative z-0 mb-6 group">
        <label for="cost_price" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Cost Price:</label>
        <input type="number" id="cost_price" name="cost_price" class="form-input block w-full py-2.5 px-0 text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" step="0.01" required />
        
    </div>

    <div class="mt-6">
        <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Add Medicine</button>
    </div>
</form>

    </div>
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u567464706/domains/webiflysolutions.com/public_html/inventory/resources/views/medicine.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Sell Medicine'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h2 class="text-2xl font-semibold mb-4">Sales Receipt</h2>

        <div class="bg-white p-6 shadow-md sm:rounded-lg">
            <h3 class="text-lg font-medium mb-2"><?php echo e($sale->customer_name); ?></h3>
            <p>Date: <?php echo e($sale->date); ?></p>
            <p>Total: <?php echo e($sale->total_selling_price); ?></p>
            <p>Total Cost Price: <?php echo e($sale->total_cost_price); ?></p>
            <p>Profit: <?php echo e($sale->total_selling_price - $sale->total_cost_price); ?></p>
        </div>

        <?php if($medicine->isNotEmpty()): ?>
            <h2 class="text-2xl font-semibold mt-4">Medicine Details</h2>
            <table class="table-auto">
                <thead>
                    <tr>
                        <th class="px-4 py-2">Medicine Name</th>
                        <th class="px-4 py-2">Batch Number</th>
                        <th class="px-4 py-2">Cost Price</th>
                        <th class="px-4 py-2">Selling Price</th>
                        <th class="px-4 py-2">Profit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4 py-2"><?php echo e($med->medicine_name); ?></td>
                            <td class="px-4 py-2"><?php echo e($med->batch_number); ?></td>
                            <td class="px-4 py-2"><?php echo e($med->cost_price); ?></td>
                            <td class="px-4 py-2"><?php echo e($med->selling_price); ?></td>
                            <td class="px-4 py-2" style="color: <?php echo e($med->selling_price - $med->cost_price >= 0 ? 'green' : 'red'); ?>">
                                <?php echo e(($med->selling_price - $med->cost_price >= 0 ? '+' : '-') . abs($med->selling_price - $med->cost_price)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No medicine details found for this sale.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himan\Desktop\hosting\inventory\resources\views/sellView.blade.php ENDPATH**/ ?>



<?php $__env->startSection('title', 'Sell Medicine'); ?>
<script>

function total2() {
    
    const inputs = document.querySelectorAll('input[name^="cost_"]');
    let total = 0;
    
    inputs.forEach(input => {
      const value = parseFloat(input.value); // Convert the value to a number
      if (!isNaN(value)) {
        total += value;
      }
    });
    document.querySelector("input[name^=total_cost_price").value = total;
    }
  function total() {
    
    const inputs = document.querySelectorAll('input[name^="sp_"]');
    let total = 0;
    
    inputs.forEach(input => {
      const value = parseFloat(input.value); // Convert the value to a number
      if (!isNaN(value)) {
        total += value;
      }
    });
    document.getElementById("total").innerHTML = total;
    document.querySelector("input[name^=total_amount]").value = total;
    total2();
    }
 
    var items=0;
    function addItem1() {
  items++;
  var html = "<tr>";
  html +="<td>" + items + "</td>";
  html += "<td>";
  html +=
    "<input type='text' name='med_name_" + items +
    "' class='live-fetch-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'>";
  html += " <div class='dropdown-container' ></div></td>";
  html += "<td><input type='text' name='batch_number_" +items+ "' class='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'></td>";
  html += "<td><input type='number' name='cost_" +items +"' class='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'></td>";
  html += "<td><input type='number' name='mrp_" +  "' class='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'></td>";
  html += "<td><input type='number' name='sp_" +items + "' class='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500' oninput='total()'></td>";
  html +=
    "<td><button class='bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 m-3' type='button' onclick='deleteRow1(this);'>Delete</button></td>";
  html += "</tr>";
  
  
  var row = document.getElementById("tbody").insertRow();
  row.innerHTML = html;
  
  liveFetchElements2();
   const scrollAmount = 100; 
    const currentScrollY = window.scrollY;
    const newScrollY = currentScrollY + scrollAmount;
    window.scrollTo(0, newScrollY);
}
function deleteRow1(button) {
  var delete_name = button.parentElement.parentElement.children[1].children[0];
  delete_name.value = "";
  delete_name.parentElement.parentElement.style.display = "none";
}

</script>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h2 class="text-2xl font-semibold mb-4">Sell Medicine</h2>
        <?php if(session('success')): ?>
                <p class="text-green-600 font-medium mb-2"><?php echo e(session('success')); ?></p>
            <?php endif; ?>


            <!-- Add your selling form here -->
            <form action="" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Customer Name Input -->
    <div class="mb-6">
        <label for="customer_name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Customer Name</label>
        <input type="text" name="customer_name" id="customer_name" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
    </div>

    <!-- Date Input -->
    <div class="mb-6">
        <label for="sale_date" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Selling Date</label>
        <input type="date" name="sale_date" id="sale_date" value="<?php echo e(now()->format('Y-m-d')); ?>" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required>
    </div>
    <div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Add medicines</h6>
        
    </div>
    <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tr>
                        <th class="col-3">Sr. No.</th>
                        <th class="col-3">Medicine</th>
                        <th class="col-3">Batch No.</th>
                        <th class="col-3">Cost Price</th>
                        <th class="col-3">Mrp</th>
                        <th class="col-1">Selling Price</th>
                        <th class="col-1">Delete</th>
                    </tr>
                    <tbody id="tbody">
                    
                    </tbody>
                </table>
            </div>
            <div><strong>Total:</strong> Rs. <span id="total"> 00.00</span></div>
            <button type="button" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 m-3" onclick="addItem1();">Add Medicine</button>
       
    </div>
</div>


<input type="hidden" name="total_amount">
<input type="hidden" name="total_cost_price">
    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
        Sell
    </button>
</form>


        </div>
    </div>

<?php $__env->stopSection(); ?>
<script>
// Variable to store the timeout ID
let debounceTimeout2;

// Attach event listener to the live-fetch inputs and textareas
var liveFetchElements2 = () => {
  document.querySelectorAll(".live-fetch-2").forEach(function (element) {
    // Attach event handler to each element
    element.addEventListener("input", function () {
      var inputValue = this.value;
      var dropdownContainer = this.nextElementSibling;

      // Clear the dropdown container
      dropdownContainer.innerHTML = "";

      // Clear the previous timeout (if any) to prevent the previous request from being sent
    //   clearTimeout(debounceTimeout);

      // Set a new timeout to send the request after 1 second of the user's last input
      debounceTimeout = setTimeout(function () {

    const apiUrl = `/api-medicine/data?input=${inputValue}`;
        // Fetch dropdown menu content from the server based on the input value and column name
        fetch( apiUrl
        )
          .then((response) => response.json())
          .then((data) => {
            // Build the dropdown menu rows
            var dropdownRows = "";
            data.forEach((option) => {
              // Display the 'columnToShow' value in the dropdown
              dropdownRows += `<div class="dropdown-row" data-stored="${encodeURIComponent(
                JSON.stringify(option)
              )}" >${option.medicine_name}</div>`;
            });
           
      
  

            // Append the dropdown rows to the container
            dropdownContainer.innerHTML = dropdownRows;

            // Show the dropdown container
            dropdownContainer.style.display = "block";
          })
          .catch((error) => {
            console.error(
              "Failed to fetch dropdown content from the server.",
              error
            );
          });
      }, 100); // Debounce time
    });
  });
};
liveFetchElements2();

// Attach click event handler to the document
document.addEventListener("click", function (event) {
  var dropdownRow = event.target;

  // Check if the clicked element is a dropdown row
  if (dropdownRow.classList.contains("dropdown-row")) {
    var hell = dropdownRow.getAttribute("data-stored");
    var data = JSON.parse(decodeURIComponent(hell));

    var inputOrTextarea = dropdownRow.parentNode.previousElementSibling;
    var row = inputOrTextarea.closest("tr");
   row.children[2].children[0].value = data.batch_number;
   row.children[3].children[0].value = data.cost_price;
   row.children[4].children[0].value = data.mrp;

   
    // Fill the input or textarea with the selected row's value
    inputOrTextarea.value = dropdownRow.textContent;

    // Hide the dropdown container
    dropdownRow.parentNode.style.display = "none";
  }
});

// Hide the dropdown container when clicking outside of it
document.addEventListener("click", function () {
  document.querySelectorAll(".dropdown-container").forEach((e) => {
    e.style.display = "none";
  });
});



</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himan\Desktop\hosting\inventory\resources\views/bulkSell.blade.php ENDPATH**/ ?>
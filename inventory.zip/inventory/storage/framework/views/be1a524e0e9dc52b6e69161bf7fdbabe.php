

<?php $__env->startSection('title', 'Medicine List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6">
        <h2 class="text-2xl font-semibold mb-4">Medicine List</h2>

        <!-- Search Form -->
        <form method="GET" action="">
    <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
    <div class="relative">
        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
            </svg>
        </div>
        <input type="search" id="default-search" name="search" class="block w-full p-4 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 " placeholder="Search Medicine, Batch No., Date...."  value="<?php echo e($search); ?>">
        <button type="submit" class="text-white absolute right-2.5 bottom-2.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-blue-600 dark:hover-bg-blue-700 dark:focus-ring-blue-800">Search</button>
    </div>
</form>


        <div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-4">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            Date
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Medicine Name
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Batch Number
                        </th>
                        <th scope="col" class="px-6 py-3">
                            MRP
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Cost Price
                        </th>
                        <th scope="col" class="px-6 py-3">
                            <span class="sr-only">Edit</span>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                <?php echo e($medicine->date); ?>

                            </th>
                            <td class="px-6 py-4">
                                <?php echo e($medicine->medicine_name); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($medicine->batch_number); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($medicine->mrp); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php echo e($medicine->cost_price); ?>

                            </td>
                            <td class="px-6 py-4 text-right">
                            <a href="<?php echo e(route('sell', ['id' => $medicine->id])); ?>" class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Sell</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4">
            <?php echo e($medicines->links()); ?> <!-- Display pagination links -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himan\Desktop\hosting\inventory\resources\views/showMedicine.blade.php ENDPATH**/ ?>
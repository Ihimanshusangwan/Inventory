const searchButton = document.getElementById("search-button");
const resultDiv = document.getElementById("result");

searchButton.addEventListener("click", () => {
    const startDate = document.getElementById("start-date").value;
    const endDate = document.getElementById("end-date").value;

    // Split the original date strings by '/' to get day, month, and year
    const startDateComponents = startDate.split("/");
    const endDateComponents = endDate.split("/");

    // Rearrange the components to the desired format (YYYY-MM-DD)
    const formattedStartDate = `${
        startDateComponents[2]
    }-${startDateComponents[0].padStart(
        2,
        "0"
    )}-${startDateComponents[1].padStart(2, "0")}`;
    const formattedEndDate = `${
        endDateComponents[2]
    }-${endDateComponents[0].padStart(2, "0")}-${endDateComponents[1].padStart(
        2,
        "0"
    )}`;


    const type = document.getElementById("type").value;

    // Construct the URL with query parameters
    const apiUrl = `/api/data?start=${formattedStartDate}&end=${formattedEndDate}&type=${type}`;

    // Send the request to your Laravel route
    fetch(apiUrl)
        .then((response) => {
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            return response.json();
        })
        .then((result) => {
            if (type == "sales") {
                const profit = result.totalProfit;
                const sale = result.totalSale;
                const card = `<div class="flex" ><div class=" m-4 pl-1 w-96 h-20 bg-green-400 rounded-lg shadow-md">
                <div class="flex w-full h-full py-2 px-4 bg-white rounded-lg justify-between">
                  <div class="my-auto">
                    <p class="font-bold">PROFIT</p>
                    <p class="text-lg">Rs. ${profit}</p>
                  </div>
                  <div class="my-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>                   
                  </div>
                </div>
              </div> 
              <div class=" m-4 pl-1 w-96 h-20 bg-purple-500 rounded-lg shadow-md">
                <div class="flex w-full h-full py-2 px-4 bg-white rounded-lg justify-between">
                  <div class="my-auto">
                    <p class="font-bold">SALES</p>
                    <p class="text-lg">Rs. ${sale}</p>
                  </div>
                  <div class="my-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>                   
                  </div>
                </div>
              </div></div>`;

                const table = document.createElement("table");
                table.classList.add(
                    "w-full",
                    "text-sm",
                    "text-left",
                    "text-gray-500",
                    "dark:text-gray-400"
                );

                const thead = document.createElement("thead");
                thead.classList.add(
                    "text-xs",
                    "text-gray-700",
                    "uppercase",
                    "bg-gray-50",
                    "dark:bg-gray-700",
                    "dark:text-gray-400"
                );

                const headerRow = document.createElement("tr");
                headerRow.innerHTML = `
    <th scope="col" class="px-6 py-3">Date</th>
    <th scope="col" class="px-6 py-3">Customer Name</th>
    <th scope="col" class="px-6 py-3">Cost Price</th>
    <th scope="col" class="px-6 py-3">Selling Price</th>
    <th scope="col" class="px-6 py-3">Profit</th>
    <th scope="col" class="px-6 py-3">View</th>
`;

                thead.appendChild(headerRow);

                const tableBody = document.createElement("tbody");
                tableBody.id = "tableBody";
                const data = result.table;

                data.forEach((medicine) => {
                    const row = document.createElement("tr");
                    row.classList.add(
                        "bg-white",
                        "border-b",
                        "dark:bg-gray-800",
                        "dark:border-gray-700",
                        "hover:bg-gray-50",
                        "dark:hover-bg-gray-600"
                    );
                    row.innerHTML = `
        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
            ${medicine.date}
        </th>
        <td class="px-6 py-4">
            ${medicine.customer_name}
        </td>
        <td class="px-6 py-4">
            ${medicine.total_cost_price}
        </td>
        <td class="px-6 py-4">
            ${medicine.total_selling_price}
        </td>
        <td class="px-6 py-4" style="color: ${
            medicine.total_selling_price - medicine.total_cost_price >= 0 ? "green" : "red"
        }">
            ${
                (medicine.total_selling_price - medicine.total_cost_price >= 0
                    ? "+"
                    : "-") +
                Math.abs(medicine.total_selling_price - medicine.total_cost_price)
            }
        </td>
        <td>
        <a href="/sell/${medicine.id}" class="font-medium text-blue-600 dark:text-blue-500 hover:underline">View</a>
        </td>
    `;

                    tableBody.appendChild(row);
                });

                table.appendChild(thead);
                table.appendChild(tableBody);

                resultDiv.innerHTML = "";
                resultDiv.innerHTML = card;
                resultDiv.appendChild(table);
            } else {
                
                const Cost = result.totalCost;
                const card = `<div class=" m-4 pl-1 w-96 h-20 bg-green-400 rounded-lg shadow-md">
                <div class="flex w-full h-full py-2 px-4 bg-white rounded-lg justify-between">
                  <div class="my-auto">
                    <p class="font-bold">PURCHASE</p>
                    <p class="text-lg">Rs. ${Cost}</p>
                  </div>
                  <div class="my-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>                   
                  </div>
                </div>
              </div>`;
                const table = document.createElement("table");

                table.classList.add(
                    "w-full",
                    "text-sm",
                    "text-left",
                    "text-gray-500",
                    "dark:text-gray-400"
                );

                const thead = document.createElement("thead");
                thead.classList.add(
                    "text-xs",
                    "text-gray-700",
                    "uppercase",
                    "bg-gray-50",
                    "dark:bg-gray-700",
                    "dark:text-gray-400"
                );

                const headerRow = document.createElement("tr");
                headerRow.innerHTML = `
    <th scope="col" class="px-6 py-3">Date</th>
    <th scope="col" class="px-6 py-3">Medicine Name</th>
    <th scope="col" class="px-6 py-3">Batch Number</th>
    <th scope="col" class="px-6 py-3">MRP</th>
    <th scope="col" class="px-6 py-3">Cost Price</th>
`;

                thead.appendChild(headerRow);

                const tableBody = document.createElement("tbody");
                tableBody.id = "tableBody";
                const data = result.table;

                data.forEach((medicine) => {
                    const row = document.createElement("tr");
                    row.classList.add(
                        "bg-white",
                        "border-b",
                        "dark:bg-gray-800",
                        "dark:border-gray-700",
                        "hover:bg-gray-50",
                        "dark:hover-bg-gray-600"
                    );
                    row.innerHTML = `
        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
            ${medicine.date}
        </th>
        <td class="px-6 py-4">
            ${medicine.medicine_name}
        </td>
        <td class="px-6 py-4">
            ${medicine.batch_number}
        </td>
        <td class="px-6 py-4">
            ${medicine.mrp}
        </td>
        <td class="px-6 py-4">
            ${medicine.cost_price}
        </td>
       
      
    `;

                    tableBody.appendChild(row);
                });

                table.appendChild(thead);
                table.appendChild(tableBody);

                resultDiv.innerHTML = "";
                resultDiv.innerHTML = card;
                resultDiv.appendChild(table);
            }
        })
        .catch((error) => {
            console.error(
                "There was a problem with the fetch operation:",
                error
            );
        });
});

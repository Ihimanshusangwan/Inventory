<?php

use App\Http\Controllers\ApiController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\MedicineController;
use App\Http\Controllers\SellController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/', [LoginController::class, 'login']);
Route::any('/dashboard', [LoginController::class, 'showDashboard'])->name('dashboard');

Route::get('/add-medicine', [MedicineController::class, 'create'])->name('medicine.add');
Route::post('/add-medicine', [MedicineController::class, 'store']);
Route::get('/bulkSell', [SellController::class, 'bulkSell'])->name('medicine.bulk');
Route::post('/bulkSell', [MedicineController::class, 'sell']);
Route::any('/sales', [SellController::class, 'sales'])->name('sales');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::get('/api/data',  [ApiController::class, 'getData']);
Route::get('/api-medicine/data',  [ApiController::class, 'getMedicine']);
Route::get('/sell/{id}', [SellController::class, 'show'])->name('sell');



